    
void Credit () {
    printf("\n");
    printf("------------ CREDITS OF THIS GAME -----------\n");
    printf("1. T. Andra Oksidian Tafly\n");
    printf("2. Chistopher Billy Setiawan\n");
    printf("3. Andrian Cedric\n");
    printf("4. Abel Stanley\n");
    printf("5. Kevin Angelo\n");
    printf("----- c. 2018, Tokped Warriors. IF 2110 -----\n");
    printf("\n");
}