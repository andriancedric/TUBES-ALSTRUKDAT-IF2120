----README----

ENGI'S KITCHEN EXPANSION
Created by Tokped Warriors.
c.2018

How to play this game?
1. Open main.exe
2. Choose "NEW GAME" for those who never play this game before. Choose "LOAD GAME" to load your game.d
3. Enter your name.
4. Choose "START GAME" to start game.

Be careful! Don't let your customer waiting for a long time. Choose your best strategy to manage your restaurant.

LIST OF COMMAND:
1. GD : GO DOWN
2. GU : GO UP
3. GR : GO RIGHT
4. GL : GO LEFT
5. PLACE : Take your customer to the table/seat.
6. ORDER : Make an order from your customer.
7. CH : Empty your hand.
8. CT : Empty youur tray.
9. TAKE : Take an ingredient from kitchen.
10. PUT : Make a food from your ingredients and put it on your tray
11. GIVE : Give a food for your customer as they ordered.
12. RECIPE : Show up your recipe list.
13. SAVE : Save your game progress to an external file.
14. LOAD : Load your game progress from an external file.
